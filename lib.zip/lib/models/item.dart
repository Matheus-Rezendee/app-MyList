import 'package:hive/hive.dart';

part 'item.g.dart'; // <- este nome deve ser igual ao do arquivo!

@HiveType(typeId: 0)
class Item {
  @HiveField(0)
  final String id;

  @HiveField(1)
  final String title;

  @HiveField(2)
  final int quantity;

  @HiveField(3)
  final double price;

  @HiveField(4)
  final bool isDone;

  @HiveField(5)
  final String categoryId;

  Item({
    required this.id,
    required this.title,
    required this.quantity,
    required this.price,
    required this.isDone,
    required this.categoryId,
  });
}
